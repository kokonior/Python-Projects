# virtual-camera
Python Script for making camera lag while on Video Call/Conference like: Zoom, Discord, etc. In-reality camera doesn't lag, but it appears on Video Conference and make others feel that you Internet Bandwidth is LOW.

First read obs-installation.txt and follow steps.

Second make environment ready by installing all Python module mentioned in requirements.txt

Till the time core.py is running, video will be modified.

After running core.py wait for some time then switch on camera, and then switch to OBS-Camera
